create definer = root@localhost trigger dormid_trigger
    before INSERT
    on dorm
    for each row
BEGIN
		SET new.id=upper(REPLACE(UUID(),'-','')); -- 触发器执行的逻辑
    END;

